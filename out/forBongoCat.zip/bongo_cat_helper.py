import pyautogui
import time
import ctypes
from PIL import Image
import mss
import win32gui
import win32api
import win32con
import os # 导入 os 模块

# --- 用户配置 ---
WINDOW_TITLE = 'BongoCat'   # 游戏窗口的准确标题
CAT_X, CAT_Y = 3711, 799      # 默认的猫咪核心点击坐标
GIFT_IMAGE = 'gift.png'     # 礼包的图片文件名
CONFIDENCE = 0.8            # 图像识别的置信度
CHECK_INTERVAL = 1.0        # 正常模式下每次循环的间隔时间（秒）
CLICK_INTERVAL = 0.1        # 正常模式下连续点击猫咪的间隔时间（秒）
SEARCH_WIDTH = 400          # 以猫咪为中心的搜索区域宽度
SEARCH_HEIGHT = 400         # 以猫咪为中心的搜索区域高度

# --- 测试模式配置 ---
TEST_MODE_ENABLED = False   # 设置为 True 来启用测试模式
TEST_IMAGE = 'cat.png'      # 测试模式下要识别的图片
TEST_INTERVAL = 5.0         # 测试模式下的识别和点击间隔（秒）

# --- 初始化 ---
try:
    ctypes.windll.user32.SetProcessDPIAware()
except AttributeError:
    pass

# --- 核心功能函数 ---
def fast_foreground_click(x, y):
    """一个极快的“伪后台”点击，用于确保能点到重要目标."""
    original_pos = pyautogui.position()
    pyautogui.click(x, y)
    pyautogui.moveTo(original_pos)

def background_click(hwnd, x, y):
    """向指定窗口发送后台点击消息，完全不移动鼠标，用于常规点击."""
    try:
        left, top, _, _ = win32gui.GetWindowRect(hwnd)
        client_x = x - left
        client_y = y - top
        l_param = win32api.MAKELONG(client_x, client_y)
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, l_param)
        time.sleep(0.05)
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, l_param)
    except win32gui.error:
        pass

# --- 主程序 ---
print("Bongo Cat 小助手启动...")

try:
    # --- 步骤1: 检查图片文件是否存在 ---
    if not os.path.exists(GIFT_IMAGE):
        raise FileNotFoundError(f"错误: 找不到礼包图片文件 '{GIFT_IMAGE}'。请确保它在脚本所在的文件夹中。")
    if TEST_MODE_ENABLED and not os.path.exists(TEST_IMAGE):
        raise FileNotFoundError(f"错误: 测试模式已启用，但找不到测试图片文件 '{TEST_IMAGE}'。")

    # --- 步骤2: 设置坐标 ---
    choice = input("\n是否要更新点击坐标？(直接按 Enter 使用默认坐标，输入任意字符后按 Enter 进行更新): ")
    if choice:
        input("请将鼠标光标移动到新的点击位置（猫咪礼包附近），然后按 Enter 键确认...")
        CAT_X, CAT_Y = pyautogui.position()
        print(f"坐标已更新为: X={CAT_X}, Y={CAT_Y}")
    else:
        print(f"使用默认坐标: X={CAT_X}, Y={CAT_Y}")

    # --- 步骤3: 计算区域并绑定窗口 ---
    screen_width, screen_height = win32api.GetSystemMetrics(78), win32api.GetSystemMetrics(79)
    search_left = max(0, CAT_X - SEARCH_WIDTH // 2)
    search_top = max(0, CAT_Y - SEARCH_HEIGHT // 2)
    actual_width = min(search_left + SEARCH_WIDTH, screen_width) - search_left
    actual_height = min(search_top + SEARCH_HEIGHT, screen_height) - search_top
    SEARCH_REGION = (search_left, search_top, actual_width, actual_height)
    
    print(f"\n屏幕尺寸: {screen_width}x{screen_height}")
    print(f"搜索区域: {SEARCH_REGION}")

    hwnd = win32gui.FindWindow(None, WINDOW_TITLE)
    if hwnd == 0:
        raise Exception(f"找不到标题为 '{WINDOW_TITLE}' 的窗口。请检查游戏是否打开且标题正确。")
    print(f"成功绑定到窗口: '{WINDOW_TITLE}' (句柄: {hwnd})")
    
    if TEST_MODE_ENABLED:
        print("\n*** 测试模式已启用 ***")
    
    print("\n助手运行中... 将鼠标快速移动到屏幕左上角(0,0)可强制停止。")

    # --- 步骤4: 进入主循环 ---
    gift_collected_count = 0
    with mss.mss() as sct:
        while True:
            if pyautogui.position() == (0, 0):
                print("\n检测到紧急停止信号，程序退出。")
                break
            if not win32gui.IsWindow(hwnd):
                print("\n游戏窗口已关闭，程序退出。")
                break

            monitor_region = {"top": SEARCH_REGION[1], "left": SEARCH_REGION[0], "width": SEARCH_REGION[2], "height": SEARCH_REGION[3]}
            sct_img = sct.grab(monitor_region)
            search_area_image = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")

            if TEST_MODE_ENABLED:
                # --- 测试模式逻辑 ---
                debug_filename = "debug_test_search_area.png"
                search_area_image.save(debug_filename)
                print(f"测试模式: 已将当前搜索区域保存为 '{debug_filename}'。请检查该图片。")
                
                cat_location = pyautogui.locate(TEST_IMAGE, search_area_image, confidence=CONFIDENCE)
                if cat_location:
                    print("测试模式: 找到 cat.png, 正在点击。")
                    cat_center = pyautogui.center(cat_location)
                    fast_foreground_click(SEARCH_REGION[0] + cat_center.x, SEARCH_REGION[1] + cat_center.y)
                else:
                    print("测试模式: 未能在截图中找到 cat.png。")
                
                print(f"将在 {TEST_INTERVAL} 秒后重试...")
                time.sleep(TEST_INTERVAL)

            else:
                # --- 正常模式逻辑 ---
                search_area_image.save("debug_normal_search_area.png")
                print(f"正常模式: 正在识别礼包... (已收取: {gift_collected_count})", end='\r')

                # --- 关键修复：为 locate 函数添加 try...except ---
                gift_location = None
                try:
                    gift_location = pyautogui.locate(GIFT_IMAGE, search_area_image, confidence=CONFIDENCE)
                except pyautogui.ImageNotFoundException:
                    pass # 找不到是正常情况，直接忽略

                if gift_location:
                    gift_collected_count += 1
                    print(f"检测到礼包，收取中... (本次为第 {gift_collected_count} 个)                                   ")
                    gift_center = pyautogui.center(gift_location)
                    fast_foreground_click(SEARCH_REGION[0] + gift_center.x, SEARCH_REGION[1] + gift_center.y)
                    time.sleep(1)
                else:
                    background_click(hwnd, CAT_X, CAT_Y)
                    time.sleep(CLICK_INTERVAL)
                
                time.sleep(CHECK_INTERVAL)

except KeyboardInterrupt:
    print("\n程序已手动停止。")
except Exception as e:
    print(f"\n程序因错误而终止: {e}")